# tour_de_hongrie
Online feladat 

Ha innen tölti le a képeket, akkor a .jpg és .png formátumú fájlokat egy "kepek" nevű mappába/könyvtárba kell lenni, amit indentálni kell a letöltött mappába (ha letölti a zip fájlt, s azt kibontja, abba a mappába kell a kepek nevű mappa).
